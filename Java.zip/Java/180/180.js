let expenses = [
  { category: "Дизайн", amount: 50000 },
  { category: "Разработка", amount: 180000 },
  { category: "Тестирование", amount: 40000 },
  { category: "Хостинг", amount: 25000 }
];

function analyzeBudget(expenses) {
  // 1. Общая стоимость проекта
  const total = expenses.reduce((sum, expense) => {
    return sum + expense.amount;
  }, 0);

  // 2. Самая дорогая статья расходов
  const mostExpensive = expenses.reduce((max, expense) => {
    return expense.amount > max.amount ? expense : max;
  });

  // 3. Процент каждой статьи в бюджете
  const details = expenses.map(expense => {
    const percent = (expense.amount / total) * 100;

    return {
      category: expense.category,
      amount: expense.amount,
      percent: Number(percent.toFixed(2))
    };
  });

  return {
    total,
    mostExpensive,
    details
  };
}

const result = analyzeBudget(expenses);

console.log(`Общая стоимость проекта: ${result.total} руб.`);
console.log(
  `Самая дорогая статья: ${result.mostExpensive.category} — ` +
  `${result.mostExpensive.amount} руб.`
);

console.log("Распределение бюджета:");

result.details.forEach(expense => {
  console.log(
    `${expense.category}: ${expense.amount} руб. — ` +
    `${expense.percent}%`
  );
});
